﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Aeropuerto<T> where T : IAvion
    {
        private List<T> vuelos;

        public Aeropuerto()
        {
            
        }

        public void FinalizarVuelos()
        {
            foreach(Avion avion in vuelos)
            {
                avion.Estrellar();
            }
        }

        public static explicit operator String(Aeropuerto <T> a)
        {
            int result=0;
            foreach(Avion avion in a.vuelos)
            {
                if (avion.Estado == Aeropuerto.EstadoVuelo.volando)
                {
                    result++;
                }
            }
            return "El aeropuerto cuenta con "+result+" vuelos en estado Volando";
        }
        /// <summary>
        /// El operator + agregará un vuelo a la lista y retornará a.vuelos.Count * 50 
        /// </summary>
        /// <param name="a"></param>
        /// <param name="vuelo"></param>
        /// <returns></returns>
        public static int operator +(Aeropuerto<T> a, T vuelo)
        {
            a.vuelos.Add(vuelo);
            return (a.vuelos.Count * 50);
        }

    }
}
