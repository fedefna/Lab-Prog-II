using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntidadesSPyFinal;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Tren tren = new Tren(50,EFabricante.AtadosConAlambreTransportes,8);
            Assert.AreEqual("Corre corre trencito", tren.Transportar(tren));
        }
    }
}
