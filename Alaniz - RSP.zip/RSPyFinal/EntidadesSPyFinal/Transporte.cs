﻿namespace EntidadesSPyFinal
{
    
    public abstract class Transporte
    {
        protected int velocidad;
        protected EFabricante fabricante;
        /// <summary>
        /// Properties
        /// </summary>
        public EFabricante Fabricante { get => fabricante; set => fabricante = value; }
        public int Velocidad { get => velocidad; set => velocidad = value; }

        /// <summary>
        /// Methods
        /// </summary>
        /// <returns></returns>
        public abstract string Transportar(Transporte t);
        public abstract string ToString();
    }
}
