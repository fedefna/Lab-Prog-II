﻿namespace EntidadesSPyFinal
{
    public enum EFabricante
    {
        PatitosTransportes,
        AtadosConAlambreTransportes
    }
}