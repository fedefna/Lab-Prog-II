﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesSPyFinal
{
    [Serializable]
    public class Avion : Transporte
    {
        [field: NonSerialized]
        public event DelegadoTransporte EventoTransporte;

        private string aerolinea;
        protected EFabricante fabricante;

        public string Aerolinea { get => aerolinea; set => aerolinea = value; }

        public Avion()
        {

        }

        public override string Transportar(Transporte transporte)
        {
            if(EventoTransporte is null)
            {
                return "Vuela vuela avionsito.";
            }
            else
            {
                throw new AvionException("No pudo volar");
            }
            
        }

        public override string ToString()
        {
            throw new NotImplementedException();
        }

        public Avion(int velocidad, EFabricante fabricante, string aerolinea)
        {
            this.velocidad = velocidad;
            this.fabricante = fabricante;
            this.aerolinea = aerolinea;
        }

        public void EjecutarDelegado()
        {
            this.EventoTransporte.Invoke(this);
        }
    }
}
