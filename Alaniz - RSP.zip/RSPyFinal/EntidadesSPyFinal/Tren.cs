﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesSPyFinal
{
    public class Tren : Transporte
    {
        public event DelegadoTransporte EventoTransporte;

        private int canVagones;
        protected EFabricante fabricante;

        public override string Transportar(Transporte t)
        {
            return "Corre corre trencito";
        }

        public Tren(int velocidad,EFabricante fabricante, int cantidadVagones)
        {
            this.canVagones = cantidadVagones;
            this.fabricante = fabricante;
            this.velocidad = velocidad;
        }

        public void EjecutarDelegado()
        {
            this.EventoTransporte.Invoke(this);
        }

        public override string ToString()
        {
            throw new NotImplementedException();
        }
    }
}
