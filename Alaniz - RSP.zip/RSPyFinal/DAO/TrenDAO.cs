﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using EntidadesSPyFinal;

namespace Datos
{
    public class TrenDAO :IData<Transporte>
    {

        static string connectionString;
        public static SqlCommand comando;
        public static SqlConnection conexion;

        /// <summary>
        /// Asigna un valor al connectionString
        /// </summary>
        static TrenDAO()
        {
            string dbName = "Viajes";
            connectionString = "Data Source=.\\SQLEXPRESS; Initial Catalog=" + dbName + "; Integrated Security=True;";

            try
            {
                conexion = new SqlConnection(connectionString);
                comando = new SqlCommand();
                comando.CommandType = System.Data.CommandType.Text;
                comando.Connection = conexion;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Guardar guarda un objeto del tipo tren en la base de datos
        /// </summary>
        /// <param name="entity"></param>
        public void Guardar(Transporte entity)
        {
            try
            {
                Tren tren = (Tren)entity;
                string insert = "INSERT INTO trenes (cantidad_vagones,fabricante,velocidad) VALUES("+8+",'" + tren.Fabricante+ "','" + tren .Velocidad+ "')";
                comando.CommandText = insert;
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }
        }

        /// <summary>
        /// Leer Lee de la base de datos y devuelve una lista de trenes.
        /// </summary>
        public List<Tren> Leer()
        {
            List<Tren> lstTrenes = new List<Tren>();
            Tren tren;

            string consulta = String.Format("Select * from trenes");

            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                SqlDataReader oDr = comando.ExecuteReader();

                while (oDr.Read())
                {
                    int cantVagones = int.Parse(oDr["cantidad_vagones"].ToString());
                    EFabricante fabricante = (EFabricante)Enum.Parse(typeof(EFabricante), oDr["fabricante"].ToString());
                    int velocidad = int.Parse(oDr["Velocidad"].ToString());
                    tren = new Tren(cantVagones,fabricante,velocidad);
                    lstTrenes.Add(tren);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }

            return lstTrenes;
        }
    }
}
