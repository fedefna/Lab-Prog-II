﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using EntidadesSPyFinal;

namespace Datos
{
    public class AvionXML : IData<Avion>
    {
        private static readonly string rutaArchivo;

        /// <summary>
        /// Asigna un valor al connectionString
        /// </summary>
        static AvionXML()
        {
            rutaArchivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Aviones.xml "; ;
        }
        /// <summary>
        /// Guardar recibe serializa un objeto Avion en XML en el escritorio.
        /// </summary>
        /// <param name="entity"></param>
        public void Guardar(Avion entity)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Avion));
                XmlTextWriter wtr = new XmlTextWriter(rutaArchivo, Encoding.UTF8);
                serializer.Serialize(wtr, entity);
                wtr.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /// <summary>
        /// Leer deserializar el objeto.
        /// </summary>
        /// <returns></returns>
        public Avion Leer()
        {
            XmlTextReader rdr = new XmlTextReader(rutaArchivo);
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Avion));
                return (Avion)serializer.Deserialize(rdr);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                rdr.Close();
            }
        }
    }
}
