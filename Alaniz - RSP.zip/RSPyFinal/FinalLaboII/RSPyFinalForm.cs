﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using Datos;
using EntidadesSPyFinal;

namespace FinalLaboII
{
    public partial class RSPyFinalForm : Form
    {
        public List<Transporte> listaTransportes;
        public List<Thread> hilos;
        public RSPyFinalForm()
        {
            InitializeComponent();
            this.hilos = new List<Thread> ();
            this.cmbFabricante.DataSource = Enum.GetNames(typeof(EFabricante));
        }
        /// <summary>
        /// El botón Guardar Avion usa AvionXml para guardar un avión en un archivo de xml.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            EFabricante fabricante;
            Enum.TryParse(this.cmbFabricante.SelectedItem.ToString(), out fabricante);

            Avion avion = new Avion(int.Parse(this.txtVelocidad.Text), fabricante, this.txtAerolineaEmpresa.Text);

            AvionXML av = new AvionXML();
            av.Guardar(avion);
        }

        private void BtnViajar_Click(object sender, EventArgs e)
        {

        }

        private void BtnMostrarTrenes_Click(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// ComenzarViaje: método que recibe un objeto del tipo Transporte y muestra en un Messagebox con
        /// el mensaje retornado por el método Transportar.
        /// </summary>
        /// <param name="transporte"></param>
        private void ComenzarViaje(Transporte transporte)
        {
            MessageBox.Show(transporte.Transportar(transporte));
        }

        /// <summary>
        /// El botón Iniciar Viaje Tren lee los datos del form y agregar al Evento el manejador
        /// “TrenDAO.Guardar” y “ComenzarViaje” y ejecutar el método EjecutarEvento en un hilo nuevo.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnMostrarAvion_Click(object sender, EventArgs e)
        {
            EFabricante fabricante;
            Enum.TryParse(this.cmbFabricante.SelectedItem.ToString(), out fabricante);

            Tren tren = new Tren(int.Parse(this.txtVelocidad.Text), fabricante, 4);
            TrenDAO trenDao = new TrenDAO();
            tren.EventoTransporte += trenDao.Guardar;            
            tren.EventoTransporte += this.ComenzarViaje;

            Thread thread = new Thread(tren.EjecutarDelegado);
            thread.Start();

            this.hilos.Add(thread);
        }
        /// <summary>
        /// El botón Guardar Tren usa TrenDAO para guardar un tren en la base de datos.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAgregarTren_Click(object sender, EventArgs e)
        {
            Tren tren = new Tren(int.Parse(this.txtVelocidad.Text), (EFabricante)Enum.Parse(typeof(EFabricante), this.cmbFabricante.SelectedItem.ToString()),8);
            //Guardo el tren
        }
        /// <summary>
        /// Cuando se cierra la aplicación abortar todos los hilos.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RSPyFinalForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            foreach (var item in this.hilos)
            {
                item.Abort();
            }
        }
    }
}
